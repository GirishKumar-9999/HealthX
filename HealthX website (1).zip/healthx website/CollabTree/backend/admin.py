from django.contrib import admin
from backend.models import UserAttribs, Service

admin.site.register(UserAttribs)
admin.site.register(Service)
